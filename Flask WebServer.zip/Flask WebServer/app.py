from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def homepage():
    context = {}
    context["Logo"] = "img/logomercado.png"
    context["img"]  = "img/banner.png"
    context["Título"] = "SuperMercado Lagoa"
    context["Texto"] = "Seja bem vindo ao Mercado Lagoa"
    context["Desc"] = "Aqui você encontra tudo o que precisa em um só lugar! Produtos frescos, ofertas imperdíveis e a comodidade de comprar online com entrega rápida. Faça suas compras com segurança e praticidade. Aproveite nossas promoções e leve mais economia para sua casa!"
    return render_template("homepage.html", **context)

@app.route('/add_produto')
def add_produto():
    produtos = {}
    context = {}
    context["Logo"] = "img/senailogo.png"
    produtos[1] = "Arroz"
    produtos[2] = "Azeite"
    produtos[3] = "Café"
    context["produtos"] = produtos
    return render_template("add_produto.html", **context)

@app.route('/del_produto')
def del_produto():
    context = {}
    context["Logo"] = "img/senailogo.png"
    return render_template("del_produto.html", context=context)

@app.route('/up_produto')
def up_produto():
    context = {}
    context["Logo"] = "img/senailogo.png"
    return render_template("up_produto.html", context=context)



if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")